﻿namespace ATS_714230064
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.NPMtextBox1 = new System.Windows.Forms.TextBox();
            this.NamatextBox2 = new System.Windows.Forms.TextBox();
            this.AlamattextBox3 = new System.Windows.Forms.TextBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.TahuntextBox4 = new System.Windows.Forms.TextBox();
            this.KelastextBox5 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.PilihMataKuliah = new System.Windows.Forms.Button();
            this.groupBox1Semester = new System.Windows.Forms.GroupBox();
            this.Semester3RadioButton = new System.Windows.Forms.RadioButton();
            this.Semester2RadioButton = new System.Windows.Forms.RadioButton();
            this.Semester1RadioButton = new System.Windows.Forms.RadioButton();
            this.groupBox2MataKuliah = new System.Windows.Forms.GroupBox();
            this.PengantarLogistikCheckBox = new System.Windows.Forms.CheckBox();
            this.PendidikanPancasilaCheckBox = new System.Windows.Forms.CheckBox();
            this.AlgoritmaStrukturData2CheckBox = new System.Windows.Forms.CheckBox();
            this.AlgoritmaStrukturData1CheckBox = new System.Windows.Forms.CheckBox();
            this.LiterasiDataCheckBox = new System.Windows.Forms.CheckBox();
            this.BasisDataIICheckBox = new System.Windows.Forms.CheckBox();
            this.BasisDataICheckBox = new System.Windows.Forms.CheckBox();
            this.LiterasiTeknologiCheckBox = new System.Windows.Forms.CheckBox();
            this.PemrogramanIICheckBox = new System.Windows.Forms.CheckBox();
            this.PemrogramanICheckBox = new System.Windows.Forms.CheckBox();
            this.AljabarLinierCheckBox = new System.Windows.Forms.CheckBox();
            this.MatematikaDiskritCheckBox = new System.Windows.Forms.CheckBox();
            this.SimpanButton = new System.Windows.Forms.Button();
            this.BatalButton = new System.Windows.Forms.Button();
            this.groupBox1Semester.SuspendLayout();
            this.groupBox2MataKuliah.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(258, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(443, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "PILIHAN MATA KULIAH MAHASISWA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "NPM";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Nama";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Jenis Kelamin";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 185);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Alamat";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(545, 150);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Kelas";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(545, 74);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "Program Studi";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(545, 112);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(128, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "Tahun Akademik";
            // 
            // NPMtextBox1
            // 
            this.NPMtextBox1.Location = new System.Drawing.Point(132, 68);
            this.NPMtextBox1.Name = "NPMtextBox1";
            this.NPMtextBox1.Size = new System.Drawing.Size(240, 26);
            this.NPMtextBox1.TabIndex = 8;
            this.NPMtextBox1.TextChanged += new System.EventHandler(this.NPMtextBox1_TextChanged);
            // 
            // NamatextBox2
            // 
            this.NamatextBox2.Location = new System.Drawing.Point(132, 112);
            this.NamatextBox2.Name = "NamatextBox2";
            this.NamatextBox2.Size = new System.Drawing.Size(240, 26);
            this.NamatextBox2.TabIndex = 9;
            this.NamatextBox2.TextChanged += new System.EventHandler(this.NamatextBox2_TextChanged);
            // 
            // AlamattextBox3
            // 
            this.AlamattextBox3.Location = new System.Drawing.Point(132, 175);
            this.AlamattextBox3.Multiline = true;
            this.AlamattextBox3.Name = "AlamattextBox3";
            this.AlamattextBox3.Size = new System.Drawing.Size(240, 77);
            this.AlamattextBox3.TabIndex = 10;
            this.AlamattextBox3.TextChanged += new System.EventHandler(this.AlamattextBox3_TextChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(132, 145);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(99, 24);
            this.radioButton1.TabIndex = 11;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Laki - laki";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(237, 145);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(116, 24);
            this.radioButton2.TabIndex = 12;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Perempuan";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // TahuntextBox4
            // 
            this.TahuntextBox4.Location = new System.Drawing.Point(690, 109);
            this.TahuntextBox4.Name = "TahuntextBox4";
            this.TahuntextBox4.Size = new System.Drawing.Size(240, 26);
            this.TahuntextBox4.TabIndex = 13;
            this.TahuntextBox4.TextChanged += new System.EventHandler(this.TahuntextBox4_TextChanged);
            // 
            // KelastextBox5
            // 
            this.KelastextBox5.Location = new System.Drawing.Point(690, 147);
            this.KelastextBox5.Name = "KelastextBox5";
            this.KelastextBox5.Size = new System.Drawing.Size(240, 26);
            this.KelastextBox5.TabIndex = 14;
            this.KelastextBox5.TextChanged += new System.EventHandler(this.KelastextBox5_TextChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "D4 Teknik Informatika",
            "D3 Teknik Informatika"});
            this.comboBox1.Location = new System.Drawing.Point(690, 68);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(240, 28);
            this.comboBox1.TabIndex = 15;
            // 
            // PilihMataKuliah
            // 
            this.PilihMataKuliah.Location = new System.Drawing.Point(754, 203);
            this.PilihMataKuliah.Name = "PilihMataKuliah";
            this.PilihMataKuliah.Size = new System.Drawing.Size(176, 56);
            this.PilihMataKuliah.TabIndex = 16;
            this.PilihMataKuliah.Text = "Pilih Mata Kuliah";
            this.PilihMataKuliah.UseVisualStyleBackColor = true;
            this.PilihMataKuliah.Click += new System.EventHandler(this.PilihMataKuliah_Click);
            // 
            // groupBox1Semester
            // 
            this.groupBox1Semester.Controls.Add(this.Semester3RadioButton);
            this.groupBox1Semester.Controls.Add(this.Semester2RadioButton);
            this.groupBox1Semester.Controls.Add(this.Semester1RadioButton);
            this.groupBox1Semester.Location = new System.Drawing.Point(28, 352);
            this.groupBox1Semester.Name = "groupBox1Semester";
            this.groupBox1Semester.Size = new System.Drawing.Size(224, 194);
            this.groupBox1Semester.TabIndex = 17;
            this.groupBox1Semester.TabStop = false;
            this.groupBox1Semester.Text = "Semester";
            // 
            // Semester3RadioButton
            // 
            this.Semester3RadioButton.AutoSize = true;
            this.Semester3RadioButton.Location = new System.Drawing.Point(9, 112);
            this.Semester3RadioButton.Name = "Semester3RadioButton";
            this.Semester3RadioButton.Size = new System.Drawing.Size(116, 24);
            this.Semester3RadioButton.TabIndex = 2;
            this.Semester3RadioButton.TabStop = true;
            this.Semester3RadioButton.Text = "Semester 3";
            this.Semester3RadioButton.UseVisualStyleBackColor = true;
            this.Semester3RadioButton.CheckedChanged += new System.EventHandler(this.Semester3RadioButton_CheckedChanged);
            // 
            // Semester2RadioButton
            // 
            this.Semester2RadioButton.AutoSize = true;
            this.Semester2RadioButton.Location = new System.Drawing.Point(9, 70);
            this.Semester2RadioButton.Name = "Semester2RadioButton";
            this.Semester2RadioButton.Size = new System.Drawing.Size(116, 24);
            this.Semester2RadioButton.TabIndex = 1;
            this.Semester2RadioButton.TabStop = true;
            this.Semester2RadioButton.Text = "Semester 2";
            this.Semester2RadioButton.UseVisualStyleBackColor = true;
            this.Semester2RadioButton.CheckedChanged += new System.EventHandler(this.Semester2RadioButton_CheckedChanged);
            // 
            // Semester1RadioButton
            // 
            this.Semester1RadioButton.AutoSize = true;
            this.Semester1RadioButton.Location = new System.Drawing.Point(9, 26);
            this.Semester1RadioButton.Name = "Semester1RadioButton";
            this.Semester1RadioButton.Size = new System.Drawing.Size(116, 24);
            this.Semester1RadioButton.TabIndex = 0;
            this.Semester1RadioButton.TabStop = true;
            this.Semester1RadioButton.Text = "Semester 1";
            this.Semester1RadioButton.UseVisualStyleBackColor = true;
            this.Semester1RadioButton.CheckedChanged += new System.EventHandler(this.Semester1RadioButton_CheckedChanged);
            // 
            // groupBox2MataKuliah
            // 
            this.groupBox2MataKuliah.Controls.Add(this.PengantarLogistikCheckBox);
            this.groupBox2MataKuliah.Controls.Add(this.PendidikanPancasilaCheckBox);
            this.groupBox2MataKuliah.Controls.Add(this.AlgoritmaStrukturData2CheckBox);
            this.groupBox2MataKuliah.Controls.Add(this.AlgoritmaStrukturData1CheckBox);
            this.groupBox2MataKuliah.Controls.Add(this.LiterasiDataCheckBox);
            this.groupBox2MataKuliah.Controls.Add(this.BasisDataIICheckBox);
            this.groupBox2MataKuliah.Controls.Add(this.BasisDataICheckBox);
            this.groupBox2MataKuliah.Controls.Add(this.LiterasiTeknologiCheckBox);
            this.groupBox2MataKuliah.Controls.Add(this.PemrogramanIICheckBox);
            this.groupBox2MataKuliah.Controls.Add(this.PemrogramanICheckBox);
            this.groupBox2MataKuliah.Controls.Add(this.AljabarLinierCheckBox);
            this.groupBox2MataKuliah.Controls.Add(this.MatematikaDiskritCheckBox);
            this.groupBox2MataKuliah.Location = new System.Drawing.Point(283, 352);
            this.groupBox2MataKuliah.Name = "groupBox2MataKuliah";
            this.groupBox2MataKuliah.Size = new System.Drawing.Size(677, 194);
            this.groupBox2MataKuliah.TabIndex = 18;
            this.groupBox2MataKuliah.TabStop = false;
            this.groupBox2MataKuliah.Text = "Mata Kuliah Pilihan";
            // 
            // PengantarLogistikCheckBox
            // 
            this.PengantarLogistikCheckBox.AutoSize = true;
            this.PengantarLogistikCheckBox.Enabled = false;
            this.PengantarLogistikCheckBox.Location = new System.Drawing.Point(407, 153);
            this.PengantarLogistikCheckBox.Name = "PengantarLogistikCheckBox";
            this.PengantarLogistikCheckBox.Size = new System.Drawing.Size(237, 24);
            this.PengantarLogistikCheckBox.TabIndex = 11;
            this.PengantarLogistikCheckBox.Text = "Pengantar Logistik dan SCM";
            this.PengantarLogistikCheckBox.UseVisualStyleBackColor = true;
            // 
            // PendidikanPancasilaCheckBox
            // 
            this.PendidikanPancasilaCheckBox.AutoSize = true;
            this.PendidikanPancasilaCheckBox.Enabled = false;
            this.PendidikanPancasilaCheckBox.Location = new System.Drawing.Point(407, 113);
            this.PendidikanPancasilaCheckBox.Name = "PendidikanPancasilaCheckBox";
            this.PendidikanPancasilaCheckBox.Size = new System.Drawing.Size(185, 24);
            this.PendidikanPancasilaCheckBox.TabIndex = 10;
            this.PendidikanPancasilaCheckBox.Text = "Pendidikan Pancasila";
            this.PendidikanPancasilaCheckBox.UseVisualStyleBackColor = true;
            // 
            // AlgoritmaStrukturData2CheckBox
            // 
            this.AlgoritmaStrukturData2CheckBox.AutoSize = true;
            this.AlgoritmaStrukturData2CheckBox.Enabled = false;
            this.AlgoritmaStrukturData2CheckBox.Location = new System.Drawing.Point(407, 71);
            this.AlgoritmaStrukturData2CheckBox.Name = "AlgoritmaStrukturData2CheckBox";
            this.AlgoritmaStrukturData2CheckBox.Size = new System.Drawing.Size(246, 24);
            this.AlgoritmaStrukturData2CheckBox.TabIndex = 9;
            this.AlgoritmaStrukturData2CheckBox.Text = "Algoritma dan Struktur Data 2";
            this.AlgoritmaStrukturData2CheckBox.UseVisualStyleBackColor = true;
            // 
            // AlgoritmaStrukturData1CheckBox
            // 
            this.AlgoritmaStrukturData1CheckBox.AutoSize = true;
            this.AlgoritmaStrukturData1CheckBox.Enabled = false;
            this.AlgoritmaStrukturData1CheckBox.Location = new System.Drawing.Point(407, 26);
            this.AlgoritmaStrukturData1CheckBox.Name = "AlgoritmaStrukturData1CheckBox";
            this.AlgoritmaStrukturData1CheckBox.Size = new System.Drawing.Size(246, 24);
            this.AlgoritmaStrukturData1CheckBox.TabIndex = 8;
            this.AlgoritmaStrukturData1CheckBox.Text = "Algoritma dan Struktur Data 1";
            this.AlgoritmaStrukturData1CheckBox.UseVisualStyleBackColor = true;
            // 
            // LiterasiDataCheckBox
            // 
            this.LiterasiDataCheckBox.AutoSize = true;
            this.LiterasiDataCheckBox.Enabled = false;
            this.LiterasiDataCheckBox.Location = new System.Drawing.Point(221, 153);
            this.LiterasiDataCheckBox.Name = "LiterasiDataCheckBox";
            this.LiterasiDataCheckBox.Size = new System.Drawing.Size(125, 24);
            this.LiterasiDataCheckBox.TabIndex = 7;
            this.LiterasiDataCheckBox.Text = "Literasi Data";
            this.LiterasiDataCheckBox.UseVisualStyleBackColor = true;
            // 
            // BasisDataIICheckBox
            // 
            this.BasisDataIICheckBox.AutoSize = true;
            this.BasisDataIICheckBox.Enabled = false;
            this.BasisDataIICheckBox.Location = new System.Drawing.Point(221, 113);
            this.BasisDataIICheckBox.Name = "BasisDataIICheckBox";
            this.BasisDataIICheckBox.Size = new System.Drawing.Size(127, 24);
            this.BasisDataIICheckBox.TabIndex = 6;
            this.BasisDataIICheckBox.Text = "Basis Data II";
            this.BasisDataIICheckBox.UseVisualStyleBackColor = true;
            // 
            // BasisDataICheckBox
            // 
            this.BasisDataICheckBox.AutoSize = true;
            this.BasisDataICheckBox.Enabled = false;
            this.BasisDataICheckBox.Location = new System.Drawing.Point(221, 71);
            this.BasisDataICheckBox.Name = "BasisDataICheckBox";
            this.BasisDataICheckBox.Size = new System.Drawing.Size(122, 24);
            this.BasisDataICheckBox.TabIndex = 5;
            this.BasisDataICheckBox.Text = "Basis Data I";
            this.BasisDataICheckBox.UseVisualStyleBackColor = true;
            // 
            // LiterasiTeknologiCheckBox
            // 
            this.LiterasiTeknologiCheckBox.AutoSize = true;
            this.LiterasiTeknologiCheckBox.Enabled = false;
            this.LiterasiTeknologiCheckBox.Location = new System.Drawing.Point(221, 29);
            this.LiterasiTeknologiCheckBox.Name = "LiterasiTeknologiCheckBox";
            this.LiterasiTeknologiCheckBox.Size = new System.Drawing.Size(158, 24);
            this.LiterasiTeknologiCheckBox.TabIndex = 4;
            this.LiterasiTeknologiCheckBox.Text = "Literasi Teknologi";
            this.LiterasiTeknologiCheckBox.UseVisualStyleBackColor = true;
            // 
            // PemrogramanIICheckBox
            // 
            this.PemrogramanIICheckBox.AutoSize = true;
            this.PemrogramanIICheckBox.Enabled = false;
            this.PemrogramanIICheckBox.Location = new System.Drawing.Point(30, 153);
            this.PemrogramanIICheckBox.Name = "PemrogramanIICheckBox";
            this.PemrogramanIICheckBox.Size = new System.Drawing.Size(149, 24);
            this.PemrogramanIICheckBox.TabIndex = 3;
            this.PemrogramanIICheckBox.Text = "Pemrograman II";
            this.PemrogramanIICheckBox.UseVisualStyleBackColor = true;
            // 
            // PemrogramanICheckBox
            // 
            this.PemrogramanICheckBox.AutoSize = true;
            this.PemrogramanICheckBox.Enabled = false;
            this.PemrogramanICheckBox.Location = new System.Drawing.Point(30, 112);
            this.PemrogramanICheckBox.Name = "PemrogramanICheckBox";
            this.PemrogramanICheckBox.Size = new System.Drawing.Size(144, 24);
            this.PemrogramanICheckBox.TabIndex = 2;
            this.PemrogramanICheckBox.Text = "Pemrograman I";
            this.PemrogramanICheckBox.UseVisualStyleBackColor = true;
            // 
            // AljabarLinierCheckBox
            // 
            this.AljabarLinierCheckBox.AutoSize = true;
            this.AljabarLinierCheckBox.Enabled = false;
            this.AljabarLinierCheckBox.Location = new System.Drawing.Point(30, 70);
            this.AljabarLinierCheckBox.Name = "AljabarLinierCheckBox";
            this.AljabarLinierCheckBox.Size = new System.Drawing.Size(126, 24);
            this.AljabarLinierCheckBox.TabIndex = 1;
            this.AljabarLinierCheckBox.Text = "Aljabar Linier";
            this.AljabarLinierCheckBox.UseVisualStyleBackColor = true;
            // 
            // MatematikaDiskritCheckBox
            // 
            this.MatematikaDiskritCheckBox.AutoSize = true;
            this.MatematikaDiskritCheckBox.Enabled = false;
            this.MatematikaDiskritCheckBox.Location = new System.Drawing.Point(30, 29);
            this.MatematikaDiskritCheckBox.Name = "MatematikaDiskritCheckBox";
            this.MatematikaDiskritCheckBox.Size = new System.Drawing.Size(166, 24);
            this.MatematikaDiskritCheckBox.TabIndex = 0;
            this.MatematikaDiskritCheckBox.Text = "Matematika Diskrit";
            this.MatematikaDiskritCheckBox.UseVisualStyleBackColor = true;
            // 
            // SimpanButton
            // 
            this.SimpanButton.Location = new System.Drawing.Point(366, 573);
            this.SimpanButton.Name = "SimpanButton";
            this.SimpanButton.Size = new System.Drawing.Size(152, 43);
            this.SimpanButton.TabIndex = 19;
            this.SimpanButton.Text = "Simpan";
            this.SimpanButton.UseVisualStyleBackColor = true;
            this.SimpanButton.Click += new System.EventHandler(this.SimpanButton_Click);
            // 
            // BatalButton
            // 
            this.BatalButton.Location = new System.Drawing.Point(592, 573);
            this.BatalButton.Name = "BatalButton";
            this.BatalButton.Size = new System.Drawing.Size(175, 43);
            this.BatalButton.TabIndex = 20;
            this.BatalButton.Text = "Batal";
            this.BatalButton.UseVisualStyleBackColor = true;
            this.BatalButton.Click += new System.EventHandler(this.BatalButton_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 637);
            this.Controls.Add(this.BatalButton);
            this.Controls.Add(this.SimpanButton);
            this.Controls.Add(this.groupBox2MataKuliah);
            this.Controls.Add(this.groupBox1Semester);
            this.Controls.Add(this.PilihMataKuliah);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.KelastextBox5);
            this.Controls.Add(this.TahuntextBox4);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.AlamattextBox3);
            this.Controls.Add(this.NamatextBox2);
            this.Controls.Add(this.NPMtextBox1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.groupBox1Semester.ResumeLayout(false);
            this.groupBox1Semester.PerformLayout();
            this.groupBox2MataKuliah.ResumeLayout(false);
            this.groupBox2MataKuliah.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox NPMtextBox1;
        private System.Windows.Forms.TextBox NamatextBox2;
        private System.Windows.Forms.TextBox AlamattextBox3;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.TextBox TahuntextBox4;
        private System.Windows.Forms.TextBox KelastextBox5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button PilihMataKuliah;
        private System.Windows.Forms.GroupBox groupBox1Semester;
        private System.Windows.Forms.RadioButton Semester3RadioButton;
        private System.Windows.Forms.RadioButton Semester2RadioButton;
        private System.Windows.Forms.RadioButton Semester1RadioButton;
        private System.Windows.Forms.GroupBox groupBox2MataKuliah;
        private System.Windows.Forms.CheckBox LiterasiTeknologiCheckBox;
        private System.Windows.Forms.CheckBox PemrogramanIICheckBox;
        private System.Windows.Forms.CheckBox PemrogramanICheckBox;
        private System.Windows.Forms.CheckBox AljabarLinierCheckBox;
        private System.Windows.Forms.CheckBox MatematikaDiskritCheckBox;
        private System.Windows.Forms.CheckBox PengantarLogistikCheckBox;
        private System.Windows.Forms.CheckBox PendidikanPancasilaCheckBox;
        private System.Windows.Forms.CheckBox AlgoritmaStrukturData2CheckBox;
        private System.Windows.Forms.CheckBox AlgoritmaStrukturData1CheckBox;
        private System.Windows.Forms.CheckBox LiterasiDataCheckBox;
        private System.Windows.Forms.CheckBox BasisDataIICheckBox;
        private System.Windows.Forms.CheckBox BasisDataICheckBox;
        private System.Windows.Forms.Button SimpanButton;
        private System.Windows.Forms.Button BatalButton;
    }
}